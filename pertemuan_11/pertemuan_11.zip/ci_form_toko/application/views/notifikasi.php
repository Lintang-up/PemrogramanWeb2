<html>
<head> 
  <title> <?php echo $judul;?> </title>
  <style>
    .tabel_notifikasi{
      font-family: "Andale Mono", "Monotype.com", monospace;
      font-size: 40px;
      
    }
    .n{
      padding: 10px 10px 10px 10px;
      background: #FFCAC8;
    }
  </style>
</head>


<body>
  <table class= "tabel_notifikasi" align= center>
    <tr>
      <td class = "n"> <?php echo $notifikasi;?> </td>
    </tr>
  </table>
</body>

</html>

 